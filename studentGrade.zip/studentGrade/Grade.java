package studentGrade;

public class Grade {

	 private String letterGrade;
	    private double gradePoint;

	    public Grade(String letterGrade, double gradePoint) {
	        this.letterGrade = letterGrade;
	        this.gradePoint = gradePoint;
	    }

	    public String getLetterGrade() {
	        return letterGrade;
	    }

	    public double getGradePoint() {
	        return gradePoint;
	    }

	    @Override
	    public String toString() {
	        return "Grade{" +
	                "letterGrade='" + letterGrade + '\'' +
	                ", gradePoint=" + gradePoint +
	                '}';
	    }
}
