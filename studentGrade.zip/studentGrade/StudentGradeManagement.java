package studentGrade;
import java.util.*;

public class StudentGradeManagement {
	private static Map<Integer, Student> students = new HashMap<>(); // Student ID -> Student
    private static Map<String, Course> courses = new HashMap<>();    // Course Name -> Course

    public static void addStudent(int id, String name) {
        students.put(id, new Student(id, name));
        System.out.println("Student added successfully.");
    }

    public static void addCourse(String name, String instructor) {
        courses.put(name, new Course(name, instructor));
        System.out.println("Course added successfully.");
    }

    public static void assignGrade(int studentId, String courseName, String letterGrade, double gradePoint) {
        Student student = students.get(studentId);
        Course course = courses.get(courseName);

        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        if (course == null) {
            System.out.println("Course not found.");
            return;
        }

        student.addGrade(courseName, new Grade(letterGrade, gradePoint));
        System.out.println("Grade assigned successfully.");
    }

    public static void displayStudentDetails(int studentId) {
        Student student = students.get(studentId);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.println(student);
    }

    public static void displayAllStudents() {
        for (Student student : students.values()) {
            System.out.println(student);
        }
    }

    public static void main(String[] args) {
        // Adding sample data
        addStudent(1, "Alice");
        addStudent(2, "Bob");
        addCourse("Math", "Dr. Smith");
        addCourse("Science", "Dr. Brown");

        // Assigning grades
        assignGrade(1, "Math", "A", 4.0);
        assignGrade(1, "Science", "B", 3.0);
        assignGrade(2, "Math", "A", 4.0);

        // Displaying students and their details
        displayStudentDetails(1);
        displayStudentDetails(2);
        
        // Displaying all students
        System.out.println("\nAll Students:");
        displayAllStudents();
    }

}
