package studentGrade;
import java.util.*;

public class Student {

	 private int id;
	    private String name;
	    private Map<String, Grade> grades; // Course name -> Grade

	    public Student(int id, String name) {
	        this.id = id;
	        this.name = name;
	        this.grades = new HashMap<>();
	    }

	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }

	    public void addGrade(String courseName, Grade grade) {
	        grades.put(courseName, grade);
	    }

	    public double calculateGPA() {
	        if (grades.isEmpty()) return 0.0;

	        double totalPoints = 0;
	        for (Grade grade : grades.values()) {
	            totalPoints += grade.getGradePoint();
	        }
	        return totalPoints / grades.size();
	    }

	    @Override
	    public String toString() {
	        return "Student{" +
	                "id=" + id +
	                ", name='" + name + '\'' +
	                ", GPA=" + calculateGPA() +
	                '}';
	    }
	}


