package ecommerce;
import java.util.*;
public class EcommerceProductManagement {
	private static List<Product> products = new ArrayList<>();
    private static List<Customer> customers = new ArrayList<>();
    private static List<Order> orders = new ArrayList<>();

    public static void addProduct(int id, String name, double price, int stock) {
        products.add(new Product(id, name, price, stock));
        System.out.println("Product added successfully.");
    }

    public static void removeProduct(int id) {
        products.removeIf(product -> product.getId() == id);
        System.out.println("Product removed successfully.");
    }

    public static void addCustomer(int id, String name) {
        customers.add(new Customer(id, name));
        System.out.println("Customer added successfully.");
    }

    public static void createOrder(int orderId, int customerId) {
        Customer customer = customers.stream().filter(c -> c.getId() == customerId).findFirst().orElse(null);
        if (customer == null) {
            System.out.println("Customer not found.");
            return;
        }
        orders.add(new Order(orderId, customer));
        System.out.println("Order created successfully.");
    }

 

    public static void displayOrders() {
        System.out.println("\nOrders:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }

    public static void main(String[] args) {
        // Adding products
        addProduct(1, "Laptop", 1000.0, 10);
        addProduct(2, "Phone", 500.0, 20);

        // Adding customers
        addCustomer(1, "Alice");
        addCustomer(2, "Bob");

        // Creating and managing orders
        createOrder(1, 1);
       

        createOrder(2, 2);
 

        // Displaying orders
        displayOrders();
    }

}
