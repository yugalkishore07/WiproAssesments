package junitTest;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorTest {

	Calculator calc;

    @BeforeEach
    void setUp() {
        calc = new Calculator();
    }

    // ------------- SUBTRACTION TESTS -------------  
    @Test
    @Order(1)
    void testSubtractionWithPositiveNumbers() {
        assertEquals(5, calc.subtract(10, 5));
    }

    @Test
    @Order(2)
    void testSubtractionWithNegativeNumbers() {
        assertEquals(-5, calc.subtract(-10, -5));
    }

    @Test
    @Order(3)
    void testSubtractionWithZero() {
        assertEquals(10, calc.subtract(10, 0));
    }

    @Test
    @Order(4)
    void testSubtractionWithLargeNumbers() {
        assertEquals(900000, calc.subtract(1000000, 100000));
    }

    // ------------- MULTIPLICATION TESTS -------------
    @Test
    @Order(5)
    void testMultiplicationWithPositiveNumbers() {
        assertEquals(50, calc.multiply(10, 5));
    }

    @Test
    @Order(6)
    void testMultiplicationWithNegativeNumbers() {
        assertEquals(50, calc.multiply(-10, -5));
    }

    @Test
    @Order(7)
    void testMultiplicationWithZero() {
        assertEquals(0, calc.multiply(10, 0));
    }

    @Test
    @Order(8)
    void testMultiplicationWithLargeNumbers() {
        assertEquals(1000000000, calc.multiply(1000000, 1000));
    }

    // ------------- DIVISION TESTS -------------
    @Test
    @Order(9)
    void testDivisionWithPositiveNumbers() {
        assertEquals(2, calc.divide(10, 5));
    }

    @Test
    @Order(10)
    void testDivisionWithNegativeNumbers() {
        assertEquals(2, calc.divide(-10, -5));
    }

    @Test
    @Order(11)
    void testDivisionWithZeroNumerator() {
        assertEquals(0, calc.divide(0, 10));
    }

    @Test
    @Order(12)
    void testDivisionWithLargeNumbers() {
        assertEquals(1000, calc.divide(1000000, 1000));
    }

    @Test
    @Order(13)
    void testDivisionByZeroThrowsException() {
        assertThrows(ArithmeticException.class, () -> calc.divide(10, 0));
    }
}
