package Quiz;
import java.util.*;

public class OnlineQuizSystem {
	public static void main(String[] args) {
        Quiz quiz = new Quiz();

        // Adding questions
        quiz.addQuestion("What is the capital of France?", Arrays.asList("Berlin", "Madrid", "Paris", "Rome"), 3);
        quiz.addQuestion("Which planet is known as the Red Planet?", Arrays.asList("Earth", "Mars", "Jupiter", "Venus"), 2);
        quiz.addQuestion("What is the largest mammal?", Arrays.asList("Elephant", "Blue Whale", "Giraffe", "Great White Shark"), 2);

        // Creating a user
        User user = new User("Alice");

        // Starting the quiz
        quiz.startQuiz(user);
    }
}
