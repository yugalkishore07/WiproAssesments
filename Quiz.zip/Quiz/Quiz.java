package Quiz;
import java.util.*;

public class Quiz {
	private List<Question> questions = new ArrayList<>();

    public void addQuestion(String questionText, List<String> options, int correctOption) {
        questions.add(new Question(questionText, options, correctOption));
        System.out.println("Question added successfully.");
    }

    public void startQuiz(User user) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Starting quiz for " + user.getName() + "\n");

        for (Question question : questions) {
            System.out.println(question);
            System.out.print("Your answer (1-" + question.getOptions().size() + "): ");

            int answer = scanner.nextInt();

            if (answer == question.getCorrectOption()) {
                System.out.println("Correct!\n");
                user.addScore(1);
            } else {
                System.out.println("Wrong! The correct answer was " + question.getCorrectOption() + ".\n");
            }
        }

        System.out.println("Quiz completed. " + user.getName() + "'s total score: " + user.getScore() + "\n");
    }
}
