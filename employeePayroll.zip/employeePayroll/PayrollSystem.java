package employeePayroll;
import java.util.*;
public class PayrollSystem {
	
    private static List<Employee> employees = new ArrayList<>();

    public static void addPermanentEmployee(int id, String name, String department, double baseSalary, double bonus) {
        employees.add(new PermanentEmployee(id, name, department, baseSalary, bonus));
        System.out.println("Permanent employee added successfully.");
    }

    public static void addContractualEmployee(int id, String name, String department, int hoursWorked, double hourlyRate) {
        employees.add(new ContractualEmployee(id, name, department, hoursWorked, hourlyRate));
        System.out.println("Contractual employee added successfully.");
    }

    public static void generatePayrollReport() {
        System.out.println("\nPayroll Report:");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    public static void calculateTotalSalary() {
        double total = 0;
        for (Employee employee : employees) {
            total += employee.calculateSalary();
        }
        System.out.println("\nTotal Salary for all employees: " + total);
    }

    public static void main(String[] args) {
        // Adding employees
        addPermanentEmployee(1, "Alice", "HR", 50000, 10000);
        addPermanentEmployee(2, "Bob", "Finance", 60000, 15000);
        addContractualEmployee(3, "Charlie", "IT", 120, 50);
        addContractualEmployee(4, "Diana", "Marketing", 100, 60);

        // Generating payroll report
        generatePayrollReport();

        // Calculating total salary
        calculateTotalSalary();
    }

}
