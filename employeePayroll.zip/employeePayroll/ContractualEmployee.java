package employeePayroll;

class ContractualEmployee extends Employee {
    private int hoursWorked;
    private double hourlyRate;

    public ContractualEmployee(int id, String name, String department, int hoursWorked, double hourlyRate) {
        super(id, name, department, 0); // Base salary not used for contractual employees
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    @Override
    public double calculateSalary() {
        return hoursWorked * hourlyRate;
    }

    @Override
    public String toString() {
        return super.toString() + ", hoursWorked=" + hoursWorked + ", hourlyRate=" + hourlyRate + ", totalSalary=" + calculateSalary() + '}';
    }
}