package employeePayroll;

 class PermanentEmployee extends Employee {
    private double bonus;

    public PermanentEmployee(int id, String name, String department, double baseSalary, double bonus) {
        super(id, name, department, baseSalary);
        this.bonus = bonus;
    }

    @Override
    public double calculateSalary() {
        return baseSalary + bonus;
    }

    @Override
    public String toString() {
        return super.toString() + ", bonus=" + bonus + ", totalSalary=" + calculateSalary() + '}';
    }
}