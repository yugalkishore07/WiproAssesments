package inventory;

public interface SupplierOperations {
	void addSupplier(int id, String name, String contact);
    void removeSupplier(int id);
    void listSuppliers();
}
