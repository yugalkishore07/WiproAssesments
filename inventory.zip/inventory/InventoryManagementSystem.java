package inventory;

public class InventoryManagementSystem {
	public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Adding products
        inventory.addProduct(1, "Laptop", 50, 800.00);
        inventory.addProduct(2, "Mouse", 150, 20.00);
        inventory.addProduct(3, "Keyboard", 70, 30.00);

        // Updating product quantity
        inventory.updateProductQuantity(1, 45);

        // Listing products
        inventory.listProducts();

        // Checking low stock
        inventory.checkLowStock(50);

        // Adding suppliers
        inventory.addSupplier(1, "Tech Supplies Co.", "contact@techsupplies.com");
        inventory.addSupplier(2, "Office Essentials Ltd.", "support@officeessentials.com");

        // Listing suppliers
        inventory.listSuppliers();

        // Removing a product
        inventory.removeProduct(2);

        // Listing products after removal
        inventory.listProducts();

        // Removing a supplier
        inventory.removeSupplier(1);

        // Listing suppliers after removal
        inventory.listSuppliers();
    }
}
