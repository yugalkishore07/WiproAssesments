package inventory;
import java.util.*;
class Inventory implements SupplierOperations {
    private List<Product> products = new ArrayList<>();
    private List<Supplier> suppliers = new ArrayList<>();

    // Product operations
    public void addProduct(int id, String name, int quantity, double price) {
        products.add(new Product(id, name, quantity, price));
        System.out.println("Product added successfully.");
    }

    public void updateProductQuantity(int id, int newQuantity) {
        Product product = products.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
        if (product != null) {
            product.setQuantity(newQuantity);
            System.out.println("Product quantity updated successfully.");
        } else {
            System.out.println("Error: Product not found.");
        }
    }

    public void removeProduct(int id) {
        products.removeIf(product -> product.getId() == id);
        System.out.println("Product removed successfully.");
    }

    public void listProducts() {
        System.out.println("\nProducts:");
        for (Product product : products) {
            System.out.println(product);
        }
    }

    public void checkLowStock(int threshold) {
        System.out.println("\nLow Stock Products:");
        for (Product product : products) {
            if (product.getQuantity() < threshold) {
                System.out.println(product);
            }
        }
    }

    // Supplier operations
    @Override
    public void addSupplier(int id, String name, String contact) {
        suppliers.add(new Supplier(id, name, contact));
        System.out.println("Supplier added successfully.");
    }

    @Override
    public void removeSupplier(int id) {
        suppliers.removeIf(supplier -> supplier.getId() == id);
        System.out.println("Supplier removed successfully.");
    }

    @Override
    public void listSuppliers() {
        System.out.println("\nSuppliers:");
        for (Supplier supplier : suppliers) {
            System.out.println(supplier);
        }
    }
}
