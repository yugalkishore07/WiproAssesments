package hospital;

public class Appointment {
	private int appointmentId;
    private Patient patient;
    private Doctor doctor;
    private String date;
    private String time;

    public Appointment(int appointmentId, Patient patient, Doctor doctor, String date, String time) {
        this.appointmentId = appointmentId;
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.time = time;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentId=" + appointmentId +
                ", patient=" + patient.getName() +
                ", doctor=" + doctor.getName() +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                '}';
    }

}
