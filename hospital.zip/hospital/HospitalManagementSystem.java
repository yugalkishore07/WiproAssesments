package hospital;
import java.util.*;

public class HospitalManagementSystem {
	private static List<Patient> patients = new ArrayList<>();
    private static List<Doctor> doctors = new ArrayList<>();
    private static List<Appointment> appointments = new ArrayList<>();

    public static void addPatient(int id, String name, int age, String medicalHistory) {
        patients.add(new Patient(id, name, age, medicalHistory));
        System.out.println("Patient added successfully.");
    }

    public static void addDoctor(int id, String name, String specialization) {
        doctors.add(new Doctor(id, name, specialization));
        System.out.println("Doctor added successfully.");
    }

    public static void scheduleAppointment(int appointmentId, int patientId, int doctorId, String date, String time) {
        Patient patient = patients.stream().filter(p -> p.getId() == patientId).findFirst().orElse(null);
        Doctor doctor = doctors.stream().filter(d -> d.getId() == doctorId).findFirst().orElse(null);

        if (patient == null) {
            System.out.println("Error: Patient not found.");
            return;
        }

        if (doctor == null) {
            System.out.println("Error: Doctor not found.");
            return;
        }

        appointments.add(new Appointment(appointmentId, patient, doctor, date, time));
        System.out.println("Appointment scheduled successfully.");
    }

    public static void displayAppointments() {
        System.out.println("\nAppointments:");
        for (Appointment appointment : appointments) {
            System.out.println(appointment);
        }
    }

    public static void main(String[] args) {
        // Adding patients
        addPatient(1, "Alice", 30, "Allergy");
        addPatient(2, "Bob", 45, "Diabetes");

        // Adding doctors
        addDoctor(1, "Dr. Smith", "Cardiology");
        addDoctor(2, "Dr. Brown", "Dermatology");

        // Scheduling appointments
        scheduleAppointment(1, 1, 1, "2025-01-30", "10:00 AM");
        scheduleAppointment(2, 2, 2, "2025-01-31", "02:00 PM");

        // Displaying appointments
        displayAppointments();
    }

}
