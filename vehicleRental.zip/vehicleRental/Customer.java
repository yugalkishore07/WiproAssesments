package vehicleRental;
import java.util.ArrayList;
import java.util.List;
public class Customer {

	private String name;
    private String customerId;
    private List<Vehicle> rentedVehicles;

    public Customer(String name, String customerId) {
        this.name = name;
        this.customerId = customerId;
        this.rentedVehicles = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void rentVehicle(Vehicle vehicle) {
        if (!vehicle.isRented()) {
            vehicle.rent();
            rentedVehicles.add(vehicle);
        } else {
            System.out.println("Vehicle " + vehicle.getModel() + " is already rented.");
        }
    }
}
