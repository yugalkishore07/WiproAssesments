package vehicleRental;

public class VehicleRentalSystem {
	public static void main(String[] args) {
        // Create vehicles
        Vehicle car = new Car("V001", "Sedan", 100);
        Vehicle bike = new Bike("V002", "Mountain Bike", 50);

        // Create a customer
        Customer customer = new Customer("John Doe", "C001");

        // Rent vehicles
        customer.rentVehicle(car);
        customer.rentVehicle(bike);

        // Calculate rental costs
        int days = 5;
        System.out.println("Rental cost for car: " + Rental.calculateTotalCost(car, days));
        System.out.println("Rental cost for bike: " + Rental.calculateTotalCost(bike, days));

       

        System.out.println("Vehicles returned successfully.");
    }
}
