package vehicleRental;

abstract class Vehicle {
	protected String vehicleId;
    protected String model;
    protected double rentalRatePerDay;
    protected boolean isRented;

    public Vehicle(String vehicleId, String model, double rentalRatePerDay) {
        this.vehicleId = vehicleId;
        this.model = model;
        this.rentalRatePerDay = rentalRatePerDay;
        this.isRented = false;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public String getModel() {
        return model;
    }

    public double getRentalRatePerDay() {
        return rentalRatePerDay;
    }

    public boolean isRented() {
        return isRented;
    }

    public void rent() {
        isRented = true;
    }

    public void returnVehicle() {
        isRented = false;
    }

    public abstract double calculateRentalCost(int days);
}
class Car extends Vehicle {
    private static final double INSURANCE_COST_PER_DAY = 20.0;

    public Car(String vehicleId, String model, double rentalRatePerDay) {
        super(vehicleId, model, rentalRatePerDay);
    }

    @Override
    public double calculateRentalCost(int days) {
        return (rentalRatePerDay + INSURANCE_COST_PER_DAY) * days;
    }
}

// Bike class
class Bike extends Vehicle {
    private static final double DISCOUNT_RATE = 0.9; // 10% discount for bikes

    public Bike(String vehicleId, String model, double rentalRatePerDay) {
        super(vehicleId, model, rentalRatePerDay);
    }

    @Override
    public double calculateRentalCost(int days) {
        return rentalRatePerDay * days * DISCOUNT_RATE;
    }
}
