package vehicleRental;

public class Rental {

	  public static double calculateTotalCost(Vehicle vehicle, int days) {
	        return vehicle.calculateRentalCost(days);
	    }
}
