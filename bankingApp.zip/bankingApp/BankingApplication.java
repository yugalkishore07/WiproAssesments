package bankingApp;

public class BankingApplication {

	 public static void main(String[] args) {
	        // Create customers
	        Customer customer1 = new Customer("Alice", "C001");
	        Customer customer2 = new Customer("Bob", "C002");

	        // Create accounts
	        Account savings = new SavingsAccount("S001", 1000.0);
	        Account current = new CurrentAccount("C001", 2000.0);

	        // Add accounts to customers
	        customer1.addAccount(savings);
	        customer2.addAccount(current);

	        // Perform transactions
	        System.out.println("Initial Balance:");
	        System.out.println("Savings: " + savings.getBalance());
	        System.out.println("Current: " + current.getBalance());

	        savings.deposit(500);
	        System.out.println("Savings after deposit: " + savings.getBalance());

	        current.withdraw(1500);
	        System.out.println("Current after withdrawal: " + current.getBalance());

	        Transaction.transferFunds(savings, current, 300);
	        System.out.println("Balances after transfer:");
	        System.out.println("Savings: " + savings.getBalance());
	        System.out.println("Current: " + current.getBalance());
	    }
}
