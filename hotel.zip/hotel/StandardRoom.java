package hotel;

public class StandardRoom {
	public StandardRoom(int roomNumber) {
        super();
    }
}
