package hotel;

public class DeluxeRoom {
	public DeluxeRoom(int roomNumber) {
        super();
    }
}
