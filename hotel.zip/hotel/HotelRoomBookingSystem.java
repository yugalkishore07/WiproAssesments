package hotel;

public class HotelRoomBookingSystem {
	public static void main(String[] args) {
        Hotel hotel = new Hotel();

        // Adding rooms
     

        // Adding customers
        Customer customer1 = new Customer("John Doe", 1);
        Customer customer2 = new Customer("Jane Smith", 2);

        // Booking rooms
        hotel.bookRoom(101, customer1);
        hotel.bookRoom(102, customer2);

        // Checking availability
        hotel.checkAvailability();

        // Checking out rooms
        hotel.checkOutRoom(101);

        // Checking availability after checkout
        hotel.checkAvailability();
    }
}
