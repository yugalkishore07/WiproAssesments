package hotel;
import java.util.*;
public class Hotel {
	private List<Room> rooms = new ArrayList<>();
    private List<Booking> bookings = new ArrayList<>();

    public void addRoom(Room room) {
        rooms.add(room);
        System.out.println("Room added: " + room);
    }

    public void bookRoom(int roomNumber, Customer customer) {
        Room room = rooms.stream().filter(r -> r.getRoomNumber() == roomNumber && r.isAvailable()).findFirst().orElse(null);

        if (room != null) {
            room.setAvailable(false);
            bookings.add(new Booking(room, customer));
            System.out.println("Room " + roomNumber + " booked successfully for customer: " + customer.getName());
        } else {
            System.out.println("Error: Room not available or does not exist.");
        }
    }

    public void checkOutRoom(int roomNumber) {
        Booking booking = bookings.stream().filter(b -> b.getRoom().getRoomNumber() == roomNumber).findFirst().orElse(null);

        if (booking != null) {
            booking.getRoom().setAvailable(true);
            bookings.remove(booking);
            System.out.println("Room " + roomNumber + " checked out successfully.");
        } else {
            System.out.println("Error: No booking found for room " + roomNumber);
        }
    }

    public void checkAvailability() {
        System.out.println("\nAvailable Rooms:");
        rooms.stream().filter(Room::isAvailable).forEach(System.out::println);
    }
}
